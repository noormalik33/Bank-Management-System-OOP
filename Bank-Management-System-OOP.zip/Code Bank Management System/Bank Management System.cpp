#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <ctime>
#include <algorithm>

using namespace std;

// Account interface for DIP
class IAccount 
{
    public:
        virtual ~IAccount() { }
    
        virtual void deposit(double amount) = 0;
        virtual bool withdraw(double amount) = 0;
        virtual void display() const = 0;
        virtual int get_AccountNumber() const = 0;
        virtual double get_Balance() const = 0;
        virtual string get_AccountType() const = 0; // Add this virtual function
};

// Transaction interface for DIP
class ITransaction 
{
    public:
        virtual ~ITransaction() { }
        
        virtual void addTransaction(int transId, int senderId, int receiverId, double amount, string timestamp) = 0;
        virtual void displayTransactions() const = 0;
};

// Employee interface for ISP
class IEmployee 
{
    public:
        virtual ~IEmployee() { }
        
        virtual void displayInfo() const = 0;
        virtual int get_Id() const = 0;
};


class Account : public IAccount 
{
    protected:
        int AccNumber;
        double balance;
    private:
        string AccType;
        
    public:
    	
        Account(int num, string type, double bal) : AccNumber(num), balance(bal), AccType(type) { }
        
        virtual ~Account() { }
        
        void set_AccountNumber(int num) 
		{ 
			AccNumber = num; 
		}
        void set_AccountType(string type) 
		{ 
			AccType = type; 
		}
        void set_Balance(double newBalance) 
		{ 
			balance = newBalance; 
		}
        int get_AccountNumber() const override 
		{ 
			return AccNumber; 
		}
        virtual string get_AccountType() const override 
		{ 
			return AccType; 
		}
        double get_Balance() const override 
		{ 
			return balance; 
		}
        virtual void deposit(double amount) override 
        {
            if (amount > 0) 
            {
                balance += amount;
            } 
            else 
            {
                cout << "Invalid deposit amount" << endl;
            }
        }
        virtual bool withdraw(double amount) override 
        {
            if (amount > 0 && amount <= balance) 
            {
                balance -= amount;
                return true;
            } 
            else 
            {
                cout << "Invalid or insufficient funds for withdrawal" << endl;
                return false;
            }
        }
        virtual void display() const override 
        {
            cout << "\n--------------------Account Class--------------------------\n\n";
            cout << "Account Number: " << AccNumber;
            cout << "\nBalance: " << balance;
            cout << "\nAccount Type: " << AccType;
        }
};

class SavingAccount : public Account 
{
    private:
        double InterestRate;
        
    public:
        SavingAccount(int accNum, double bal, double Rate) : Account(accNum, "Saving", bal), InterestRate(Rate) { }
        
        ~SavingAccount() override { }
        
        void deposit(double amount) override 
        {
            if (amount > 0) 
            {
                balance += amount;
                balance += (amount * InterestRate / 100);
            } 
            else 
            {
                cout << "Invalid deposit amount" << endl;
            }
        }
        double CalculateInterest() const 
		{ 
			return balance * InterestRate / 100; 
		}
        void display() const override 
        {
            Account::display();
            
            cout << "\nInterest Rate: " << InterestRate;
    	}
};

class CurrentAccount : public Account 
{
    private:
        double overDraftLimit;
        
    public:
        CurrentAccount(int accNum, double bal, double limit) : Account(accNum, "Current", bal), overDraftLimit(limit) { }
        
        ~CurrentAccount() override { }
        
        bool withdraw(double amount) override 
		{
		    if (amount > 0) 
		    {
		        if ((balance - amount) >= -overDraftLimit) 
		        {
		            balance -= amount;
		            return true;
		        } 
		        else 
		        {
		            cout << "Invalid or insufficient funds, exceeding overdraft limit" << endl;
		            return false;
		        }
		    } 
		    else 
		    {
		        cout << "Invalid amount for withdrawal" << endl;
		        return false;
		    }
		}

        void display() const override 
        {
            Account::display();
            
            cout << "\nOver Draft Limit: " << overDraftLimit;
        }
};

class Loan : public Account 
{
    private:
        double LoanAmount;
        double Interest_rate;
        
    public:
        Loan(int accNum, double LoanAmt, double rate) : Account(accNum, "Loan", LoanAmt), LoanAmount(LoanAmt), Interest_rate(rate) { }
        
        ~Loan() override { }
        
        void processInterestLoan() 
        {
            double interest = LoanAmount * Interest_rate / 100;
            LoanAmount += interest;
        }
        void repayLoan(double Amount) 
        {
            if (Amount > 0) 
            {
                LoanAmount -= Amount;
                if (LoanAmount < 0) 
                {
                    LoanAmount = 0;
                }
            } 
            else 
            {
                cout << "Invalid repayment amount" << endl;
            }
        }
        void deposit(double amount) override 
		{ 
			repayLoan(amount); 
		}
        void display() const override 
        {
            Account::display();
            
            cout << "\nLoan Amount: " << LoanAmount;
            cout << "\nInterest Rate on Loan: " << Interest_rate;
        }
};

class Cheque : public Account 
{
    private:
        int chequeNum;
        string Issuer;
        bool cashed;
        
    public:
        Cheque(int accNum, double amt, int chNum, const string& issuer) : Account(accNum, "Cheque", amt), chequeNum(chNum),
				 Issuer(issuer), cashed(false) { }
				 
        ~Cheque() override { }
        
        void deposit(double amount) override 
        {
            if (!cashed && amount == this->balance)
            {
                balance += amount;
                cashed = true;
            } 
            else 
            {
                cout << "Cheque is already cashed or amount mismatch" << endl;
            }
        }
};

class Transaction : public ITransaction 
{
    private:
        int TransactionId;
        int SenderId;
        int RecieverId;
        double amount;
        string TimeStamp;
        
    public:
        Transaction(int transid, int senderid, int recieverid, double amt, string timestamp) 
				: TransactionId(transid), SenderId(senderid), RecieverId(recieverid), amount(amt), TimeStamp(timestamp) { }
				
        ~Transaction() { }
        
        int get_TransactionID() const 
		{
			return TransactionId; 
		}
        int get_SenderID() const 
		{ 
			return SenderId; 
		}
        int get_RecieverID() const 
		{ 
			return RecieverId; 
		}
        double get_Amount() const 
		{ 
			return amount; 
		}
        string get_TimeStamp() const 
		{ 
			return TimeStamp; 
		}
        void addTransaction(int transId, int senderId, int receiverId, double amount, string timestamp) override 
        {
            // This function can be implemented to add a transaction to a list if needed
        }
        void displayTransactions() const override 
        {
            cout << "\nTransaction ID: " << TransactionId;
            cout << "\nSender ID: " << SenderId;
            cout << "\nReceiver ID: " << RecieverId;
            cout << "\nAmount: " << amount;
            cout << "\nTimestamp: " << TimeStamp << endl;
        }
};

class Employee : public IEmployee 
{
    private:
        int EmployeeId;
        string name;
        string CNIC;
        
    public:
        Employee(int id, const string& n, const string& nic) : EmployeeId(id), name(n), CNIC(nic) { }
        
        virtual ~Employee() { }
        
        void set_Name(const string& n) 
		{ 
			name = n; 
		}
        void set_Id(int id) 
		{ 
			EmployeeId = id; 
		}
        void set_CNIC(const string& cnic) 
		{ 
			CNIC = cnic; 
		}
        string get_Name() const 
		{ 
			return name; 
		}
        int get_Id() const override 
		{ 
			return EmployeeId; 
		}
        string get_CNIC() const 
		{
			return CNIC; 
		}
        void displayInfo() const 
        {
            cout << "\n----------------- Employee Information -------------------\n\n";
            cout << "\nEmployee Name: " << name;
            cout << "\nEmployee Id: " << EmployeeId;
            cout << "\nEmployee CNIC: " << CNIC;
        }
        
        friend ostream& operator<<(ostream& os, const Employee& emp) 
		{
        	os << "ID: " << emp.EmployeeId << " \nName: " << emp.name << " \nCNIC: " << emp.CNIC;
        	
			return os;
    	}
};

class BankUser 
{
    private:
        vector<IEmployee*> employees;
        vector<IAccount*> accounts;
        vector<ITransaction*> transactions;

    public:
        BankUser() {}
        
        ~BankUser() 
        {
            for (auto employee : employees) 
            {
                delete employee;
            }
            for (auto account : accounts) 
            {
                delete account;
            }
            for (auto transaction : transactions) 
            {
                delete transaction;
            }
        }

        void addEmployee(IEmployee* employee) 
		{ 
			employees.push_back(employee); 
		}
        void addAccount(IAccount* account) 
		{ 
			accounts.push_back(account); 
		}
        void addTransaction(ITransaction* transaction) 
		{ 
			transactions.push_back(transaction); 
		}

        void displayEmployee() const 
        {
            for (auto employee : employees) 
            {
                employee->displayInfo();
                cout << endl;
            }
        }

        void displayAccounts() const 
        {
            for (auto account : accounts) 
            {
                account->display();
                cout << endl;
            }
        }

        void displayTransactions() const 
        {
            for (auto transaction : transactions) 
            {
                transaction->displayTransactions();
                cout << endl;
            }
        }

        vector<IAccount*>& getAccounts() 
		{ 
			return accounts; 
		}
        vector<IEmployee*>& getEmployees() 
		{ 
			return employees; 
		}
        vector<ITransaction*>& getTransactions() 
		{ 
			return transactions;
		}

        // Function to transfer amount from one account to another
        void transferAmount(int senderAccNum, int receiverAccNum, double amount) 
        {
            IAccount* senderAcc = nullptr;
            IAccount* receiverAcc = nullptr;
            
            for (auto account : accounts) 
            {
                if (account->get_AccountNumber() == senderAccNum) 
                {
                    senderAcc = account;
                }
                if (account->get_AccountNumber() == receiverAccNum) 
                {
                    receiverAcc = account;
                }
            }
            if (senderAcc && receiverAcc && senderAcc->withdraw(amount)) 
            {
                receiverAcc->deposit(amount);
                // Get current timestamp
                time_t now = time(0);
                string timestamp = ctime(&now);
                // Add transaction
                transactions.push_back(new Transaction(transactions.size() + 1, senderAccNum, receiverAccNum, amount, timestamp));
                cout << "Transfer successful!" << endl;
            } 
            else 
            {
                cout << "Transfer failed. Please check account details and balance." << endl;
            }
        }
};


class Friend 
{
    private:
        int friend1Id;
        int friend2Id;
    public:
        Friend(int id1, int id2) : friend1Id(id1), friend2Id(id2) {}
        
        ~Friend() {}
        
        int getFriend1Id() const 
		{ 
			return friend1Id; 
		}
        int getFriend2Id() const 
		{ 
			return friend2Id; 
		}
        
        void display() const 
        {
            cout << "Friendship between Emplyee IDs: " << friend1Id << " and " << friend2Id << endl;
        }
};

class BankManager 
{
    private:
        vector<Friend> friends;
    public:
        BankManager() {}
        
        ~BankManager() {}
        
        void addFriendship(int id1, int id2) 
		{ 	
			friends.push_back(Friend(id1, id2)); 
		}
        void displayFriendships() const 
        {
            for (const auto& friendship : friends) 
            {
                friendship.display();
            }
        }
};

// Function to show the initial interface
void showInitialInterface() 
{
	cout << "\n------------------------------------------ Welcome to Bank Management System --------------------------------\n";
    cout << "\nAre you a Employee or a bank manager?" << endl;
    cout << "1. Bank Manager" << endl;
    cout << "2. Employee" << endl;
    cout << "3. Exit" << endl;
    cout << "\n*****************************";
	cout << "\nEnter your choice: ";
}

// Function to show the interface for bank manager
void showManagerInterface(BankUser& bank)
{
	ofstream outFile("AccountInformation.txt");
	
    string password, name;
    
    cout << "\nEnter You Name: ";
    cin >> name;
    
    cout << "Enter password: ";
    cin >> password;
    
    if ((password == "230940") && (name == "Sara")) 
	{        
		int choiceManager;
			
		do 
		{
			cout << "\n---------------Welcome, Bank Manager!-----------------" << endl;
	        cout << "1. Open Account\n";
		  	cout << "2. Close Account\n";
			cout << "3. Deposit Money\n";
		    cout << "4. Withdraw Money\n";
		    cout << "5. Ask for Loan\n";
		    cout << "6. Repay Loan\n";
		    cout << "7. Cash Cheque\n";
			cout << "8. Do Transaction\n";
		    cout << "9. View Transaction History\n";
		    cout << "10. View All Accounts\n";
		    cout << "11. Exit\n";
		    cout << "\n*******************************";
		    cout << "\nEnter your choice: ";	
			cin >> choiceManager;
		    cout << endl;
		
		    switch (choiceManager) 
		    {
				case 1: 
				{
				    int accNum, accType;
				    double balance, interestRate, overDraftLimit;
				    
				    cout << "Enter account number: ";
				    cin >> accNum;
				    
				    // Check if the entered account number already exists
				    bool accountExists = false;
				    for (auto account : bank.getAccounts()) 
				    {
				        if (account->get_AccountNumber() == accNum) 
				        {
				            accountExists = true;
				            break;
				        }
				    }
				    
				    if (accountExists) 
				    {
				        cout << "Error: Account number already exists!" << endl;
				        break;
				    }
				    
				    cout << "Enter initial balance: ";
				    cin >> balance;
				    
				    cout << "Select account type (1. Saving, 2. Current): ";
				    cin >> accType;
				    
				    if (accType == 1) 
				    {
				        cout << "Enter interest rate: ";
				        cin >> interestRate;
				        
				        bank.addAccount(new SavingAccount(accNum, balance, interestRate));
				    } 
				    
				    else if (accType == 2) 
				    {
				        cout << "Enter overdraft limit: ";
				        cin >> overDraftLimit;
				        bank.addAccount(new CurrentAccount(accNum, balance, overDraftLimit));
				    }
				    cout << "Account opened successfully!" << endl;
				    
				    break;
				}

		        case 2: 
				{
				    int accNum;
				
				    cout << "Enter account number to close: ";
				    cin >> accNum;
				
				    auto& accounts = bank.getAccounts();
				
				    // Find the account with the given account number
				    auto it = find_if(accounts.begin(), accounts.end(), [accNum](IAccount* account) 
					{
				        return account->get_AccountNumber() == accNum;
				    });
				
				    // Check if the account exists
				    if (it != accounts.end()) 
					{
				        // Remove the account from the vector
				        accounts.erase(it);
				        cout << "Account closed successfully!" << endl;
				    } 
					else 
					{
				        cout << "Error: Account does not exist!" << endl;
				    }
				
				    break;
				}
		        
		        case 3:
				{
				    int accNum;
				    double amount;
				    
				    cout << "Enter account number: ";
				    cin >> accNum;
				    
				    bool accountExists = false; // Flag to check if account exists
				    
				    // Check if the entered account number exists
				    for (auto account : bank.getAccounts()) 
				    {
				        if (account->get_AccountNumber() == accNum) 
				        {
				            accountExists = true;
				            break;
				        }
				    }
				    
				    if (accountExists) // If account exists, proceed with the deposit
				    {
				        cout << "Enter amount to deposit: ";
				        cin >> amount;
				        
				        for (auto account : bank.getAccounts()) 
				        {
				            if (account->get_AccountNumber() == accNum) 
				            {
				                account->deposit(amount);
				                cout << "Deposit successful!" << endl;
				            }
				        }
				    }
				    else // If account does not exist, display error message
				    {
				        cout << "Error: Account does not exist!" << endl;
				    }
				    
				    break;
				}

		        case 4: 
				{
				    int accNum;
				    double amount;
				    
				    bool accountFound = false; // Initialize a flag to track if the account was found
				    
				    cout << "Enter account number: ";
				    cin >> accNum;
				    
				    cout << "Enter amount to withdraw: ";
				    cin >> amount;
				    
				    // Check if the account exists
				    for (auto account : bank.getAccounts()) 
				    {
				        if (account->get_AccountNumber() == accNum) 
				        {
				            accountFound = true; // Set flag to true if account exists
				            
				            if (account->withdraw(amount)) 
				            {
				                cout << "Withdrawal successful!" << endl;
				            }
				            else 
				            {
				                cout << "Insufficient funds for withdrawal!" << endl;
				            }
				            
				            break; // Exit loop once account is found
				        }
				    }
				    
				    if (!accountFound) // If account was not found, display error message
				    {
				        cout << "Account not found. Please enter a valid account number." << endl;
				    }
				    
				    break;
				}

				case 5: // Ask for Loan
				{
				    int accNum;
				    double amount, interestRate;
				    
				    cout << "Enter account number: ";
				    cin >> accNum;
				    
				    bool accountExists = false;
				    
				    for (auto account : bank.getAccounts()) 
				    {
				        if (account->get_AccountNumber() == accNum) 
				        {
				            accountExists = true;
				            break;
				        }
				    }
				    
				    if (!accountExists) 
				    {
				        cout << "Account does not exist. Unable to process the loan request." << endl;
				        break;
				    }
				    
				    cout << "Enter loan amount: ";
				    cin >> amount;
				    
				    cout << "Enter interest rate: ";
				    cin >> interestRate;
				    
				    // Add loan amount from Customer account Number balance
				    for (auto account : bank.getAccounts()) 
				    {
				        if (account->get_AccountNumber() == accNum) 
				        {
				            account->deposit(amount);
				        }
				    }
				    
				    bank.addAccount(new Loan(accNum, amount, interestRate));
				    
				    cout << "Loan added successfully!" << endl;
				    
				    break;
				}
				
				case 6: // Repay Loan
				{
				    int accNum;
				    double amount;
				
				    cout << "Enter account number: ";
				    cin >> accNum;
				
				    bool accountExists = false; // Flag to check if account exists
				
				    // Check if the entered account number exists
				    for (auto account : bank.getAccounts()) 
				    {
				        if (account->get_AccountNumber() == accNum && account->get_AccountType() == "Loan") 
				        {
				            accountExists = true;
				            break;
				        }
				    }
				
				    if (!accountExists) // If account does not exist or is not a loan account, display error message
				    {
				        cout << "Error: Account does not exist or is not a loan account!" << endl;
				        break;
				    }
				
				    cout << "Enter amount to repay: ";
				    cin >> amount;
				
				    // Deduct loan repayment from the account's balance
				    for (auto account : bank.getAccounts()) 
				    {
				        if (account->get_AccountNumber() == accNum && account->get_AccountType() == "Loan") 
				        {
				            account->withdraw(amount);
				            dynamic_cast<Loan*>(account)->repayLoan(amount); // Repay loan
				
				            cout << "Loan repayment successful!" << endl;
				        }
				    }
				
				    break;
				}
					
				case 7: // Cash Cheque
				{
				    int accNum, chequeNum;
				    double amount;
				    string issuer;
				
				    cout << "Enter account number: ";
				    cin >> accNum;
				
				    // Check if the entered account number exists
				    bool accountExists = false;
				    
				    for (auto account : bank.getAccounts()) 
				    {
				        if (account->get_AccountNumber() == accNum) 
				        {
				            accountExists = true;
				            
				            break;
				        }
				    }
				
				    if (!accountExists) 
				    {
				        cout << "Error: Account does not exist. Unable to cash the cheque." << endl;
				        break;
				    }
				
				    else
				    {
				    	cout << "Enter cheque number: ";
					    cin >> chequeNum;
					
					    cout << "Enter cheque amount: ";
					    cin >> amount;
					
					    cout << "Enter issuer: ";
					    cin.ignore();
					    getline(cin, issuer);
					
					    // Credit cheque amount to the specified account
					    for (auto account : bank.getAccounts()) 
					    {
					        if (account->get_AccountNumber() == accNum) 
					        {
					            account->deposit(amount);
					        }
					    }
					
					    bank.addAccount(new Cheque(accNum, amount, chequeNum, issuer));
					
					    cout << "Cheque added successfully!" << endl;
					}
				
				    break;
				}
				
				case 8: 
		        {
		            int senderAccNum, receiverAccNum;
				    double amount;
				    
				    cout << "Enter sender account number: ";
				    cin >> senderAccNum;
				    
				    cout << "Enter receiver account number: ";
				    cin >> receiverAccNum;
				    
				    // Check if both sender and receiver accounts exist
				    bool senderExists = false;
				    bool receiverExists = false;
				    
				    for (auto account : bank.getAccounts()) 
				    {
				        if (account->get_AccountNumber() == senderAccNum) 
				        {
				            senderExists = true;
				        }
				        
				        if (account->get_AccountNumber() == receiverAccNum) 
				        {
				            receiverExists = true;
				        }
				        
				        if (senderExists && receiverExists) 
				        {
				            break;
				        }
				    }
				    
				    if (!senderExists || !receiverExists) 
				    {
				        cout << "Error: Sender or receiver account does not exist!" << endl;
				        break;
				    }
				    
				    cout << "Enter amount to transfer: ";
				    cin >> amount;
				    
				    bank.transferAmount(senderAccNum, receiverAccNum, amount);
				    
				    break;
				}
				
		        case 9: 
		        {
		            bank.displayTransactions();
		            break;
		        }
		        
	            case 10: 
				{
				    cout << "Viewing all accounts..." << endl;
				    bank.displayAccounts();
				    
				    outFile << "\t\t\t\tACCOUNT INFORMATION\n" << endl;
				    for (auto account : bank.getAccounts()) 
				    {
				        outFile << "Account Number: " << account->get_AccountNumber() << "\nAccount Type: " << account->get_AccountType() << "\nBalance: " << account->get_Balance() << endl << endl;
				    }
				    
				    break;
				}

		        case 11: 
		        {
	                cout << "Exiting program..." << endl;
	                break;
	            }
	            
	            default: 
	            {
	                cout << "Invalid choice. Please try again." << endl;
		        }
		    }
		} 
		while (choiceManager != 11);
        
    } 
	else 
	{
        cout << "Invalid Password or Name Entered. Access denied." << endl;
    }
    outFile.close();
}

//Function to show interface of Employee			
void showEmployeeInterface(BankUser& bank, Employee* employees[], int size) 
{	
	int enteredId;
    cout << "Enter your Employee ID: ";
    cin >> enteredId;

    bool employeeFound = false;
    Employee* currentEmployee = nullptr;

    for (int i = 0; i < size; ++i) 
	{
        if (employees[i]->get_Id() == enteredId) 
		{
            employeeFound = true;
            currentEmployee = employees[i];
            break;
        }
    }

    if (!employeeFound) 
	{
        cout << "Access Denied: Invalid Employee ID." << endl;
        return;
    }

    currentEmployee->displayInfo();
	
	ofstream outFile("AccountInformation.txt", ios::app);
	 
	int choiceEmployee;
		
	do 	
	{
		cout << "\n---------------- Welcome, Employee!-----------------" << endl;
	    // Customer actions here
		cout << "1. Deposit Amount" << endl;
		cout << "2. Withdrawl Amount" << endl;
		cout << "3. Request for Loan" << endl;
		cout << "4. Repay Loan" << endl;
		cout << "5. Want to cash Cheque" << endl;
		cout << "6. Do Transaction" << endl;
		cout << "7. View transaction History" << endl;
		cout << "8. Exit" << endl;
		cout << "\n********************************" << endl;
		cout << "Enter your Desired choice: ";
		cin >> choiceEmployee;
		cout << endl;

		switch (choiceEmployee) 
		{
		    case 1:
			{
			    int accNum;
			    double amount;
			    
			    cout << "Enter account number: ";
			    cin >> accNum;
			    
			    // Check if the account exists
			    bool accountExists = false;
			    for (auto account : bank.getAccounts()) 
			    {
			        if (account->get_AccountNumber() == accNum) 
			        {
			            accountExists = true;
			            break;
			        }
			    }
			    
			    if (!accountExists) 
			    {
			        cout << "Error: Account does not exist." << endl;
			        break;
			    }
			    
			    cout << "Enter amount to deposit: ";
			    cin >> amount;
			    
			    // Deposit amount into the account
			    for (auto account : bank.getAccounts()) 
			    {
			        if (account->get_AccountNumber() == accNum) 
			        {
			            account->deposit(amount);
			            cout << "Deposit successful!" << endl;
			            break;
			        }
			    }
			    break;
			}

		    case 2: 
			{
			    int accNum;
			    double amount;
			    bool accountExists = false; // Flag to check if account exists
			    
			    cout << "Enter account number: ";
			    cin >> accNum;
			    
			    // Check if the account exists
			    for (auto account : bank.getAccounts()) 
			    {
			        if (account->get_AccountNumber() == accNum) 
			        {
			            accountExists = true;
			            break; // Exit loop once account is found
			        }
			    }
			    
			    if (!accountExists) // If account does not exist
			    {
			        cout << "Error: Account does not exist!" << endl;
			        break;
			    }
			    
			    cout << "Enter amount to withdraw: ";
			    cin >> amount;
			    
			    // Perform withdrawal if account exists
			    for (auto account : bank.getAccounts()) 
			    {
			        if (account->get_AccountNumber() == accNum) 
			        {
			            if (account->withdraw(amount)) 
			            {
			                cout << "Withdrawal successful!" << endl;
			            }
			            else 
			            {
			                cout << "Error: Insufficient balance." << endl;
			            }
			        }
			    }
			    break;
			}

			case 3: // Request for Loan
			{
			    int accNum;
			    double amount, interestRate;
			    bool accountFound = false; // Flag to track if account exists
			    
			    cout << "Enter account number: ";
			    cin >> accNum;
			    
			    // Check if account exists
			    for (auto account : bank.getAccounts()) 
			    {
			        if (account->get_AccountNumber() == accNum) 
			        {
			            accountFound = true;
			            break;
			        }
			    }
			    
			    if (!accountFound) 
			    {
			        cout << "Error: Account does not exist." << endl;
			        break;
			    }
			    
			    cout << "Enter loan amount: ";
			    cin >> amount;
			    
			    cout << "Enter interest rate: ";
			    cin >> interestRate;
			    
			    // Deduct loan amount from bank's balance
			    for (auto account : bank.getAccounts()) 
			    {
			        if (account->get_AccountNumber() == accNum) 
			        {
			            account->withdraw(amount);
			        }
			    }
			    
			    bank.addAccount(new Loan(accNum, amount, interestRate));
			    
			    cout << "Loan added successfully!" << endl;
			    
			    break;
			}

			case 4: // Repay Loan
			{
			    int accNum;
			    double amount;
			
			    cout << "Enter account number: ";
			    cin >> accNum;
			
			    // Check if the account number exists
			    bool accountExists = false;
			    for (auto account : bank.getAccounts()) 
			    {
			        if (account->get_AccountNumber() == accNum && account->get_AccountType() == "Loan") 
			        {
			            accountExists = true;
			            break;
			        }
			    }
			
			    if (!accountExists) 
			    {
			        cout << "Account not found or is not a loan account. Loan repayment failed." << endl;
			        break;
			    }
			
			    cout << "Enter amount to repay: ";
			    cin >> amount;
			
			    // Deduct loan repayment from the account's balance
			    for (auto account : bank.getAccounts()) 
			    {
			        if (account->get_AccountNumber() == accNum && account->get_AccountType() == "Loan") 
			        {
			            account->withdraw(amount);
			            dynamic_cast<Loan*>(account)->repayLoan(amount); // Repay loan
			
			            cout << "Loan repayment successful!" << endl;
			        }
			    }
			    break;
			}	
		
			case 5: // Cash Cheque
			{
			    int accNum, chequeNum;
			    double amount;
			    string issuer;
			
			    cout << "Enter account number: ";
			    cin >> accNum;
			
			    // Check if the account exists
			    bool accountExists = false;
			    for (auto account : bank.getAccounts()) 
			    {
			        if (account->get_AccountNumber() == accNum ) 
			        {
			            accountExists = true;
			            break;
			        }
			    }
			
			    if (!accountExists) 
			    {
			        cout << "Error: Account not found or not a Cheque account." << endl;
			        break;
			    }
			
			    else 
			    {
			    	cout << "Enter cheque number: ";
				    cin >> chequeNum;
				
				    cout << "Enter cheque amount: ";
				    cin >> amount;
				
				    cout << "Enter issuer: ";
				    cin.ignore();
				    getline(cin, issuer);
				}
			
			    // Credit cheque amount to the specified account
			    for (auto account : bank.getAccounts()) 
			    {
			        if (account->get_AccountNumber() == accNum) 
			        {
			            account->deposit(amount);
			        }
			    }
			
			    bank.addAccount(new Cheque(accNum, amount, chequeNum, issuer));
			
			    cout << "Cheque added successfully!" << endl;
			
			    break;
			}
		            
		    case 6: 
			{
			    int senderAccNum, receiverAccNum;
			    double amount;
			    
			    cout << "Enter sender account number: ";
			    cin >> senderAccNum;
			    
			    cout << "Enter receiver account number: ";
			    cin >> receiverAccNum;
			    
			    cout << "Enter amount to transfer: ";
			    cin >> amount;
			
			    // Check if sender and receiver accounts exist
			    bool senderExists = false, receiverExists = false;
			    for (auto account : bank.getAccounts()) 
			    {
			        if (account->get_AccountNumber() == senderAccNum) 
			        {
			            senderExists = true;
			        }
			        if (account->get_AccountNumber() == receiverAccNum) 
			        {
			            receiverExists = true;
			        }
			    }
			
			    if (senderExists && receiverExists) 
			    {
			        // Perform the transfer
			        bank.transferAmount(senderAccNum, receiverAccNum, amount);
			    } 
			    else 
			    {
			        // Generate error message if either sender or receiver account does not exist
			        cout << "Error: Sender or receiver account does not exist." << endl;
			    }
			
			    break;
			}

		    case 7: 
		    {
		        bank.displayTransactions();
		        
		        break;
		    }
		    case 8: 
		    {
		        cout << "Exiting program..." << endl;
		        
		    	break;
		    }
		    default: 
		    {
		        cout << "Invalid choice. Please try again." << endl;
		    }
		}
	} 
	while (choiceEmployee != 8);
	
	outFile.close();
}

int main() 
{
	ofstream EmployeeInfo("Employee Information.txt");
	
    BankUser bank; // Create an instance of BankUser

	const int employeeArraySize = 10;
    Employee* employees[employeeArraySize] = 
	{
        new Employee(1, "Noor Malik", "313-12345-9"),
        new Employee(2, "Ayesha", "313-23456-0"),
        new Employee(3, "Aleena", "313-67895-9"),
        new Employee(4, "Aleena", "473-45678-9"),
        new Employee(5, "Laiba", "473-23789-0"),
        new Employee(6, "Noor Malik", "313-78234-9"),
        new Employee(7, "Neha", "313-63489-9"),
        new Employee(8, "Hajra", "434-12564-9"),
        new Employee(9, "Ayesha", "474-23678-0"),
        new Employee(10, "Hamna", "313-89572-0")
    };

	EmployeeInfo << "\t\t\t\tEmployee Details:\n";
	for(int i=0; i<10; i++)
	{
		EmployeeInfo << "\nInformation of " << i+1 << " Employee:";
		EmployeeInfo << "\n" << *employees[i] << endl;
	}
	
	EmployeeInfo.close();

    int choice;
    
    do 
	{
        showInitialInterface();
        
        cin >> choice;
        switch (choice) 
		{
            case 1:
                showManagerInterface(bank);
                break;
            case 2:
                showEmployeeInterface(bank,employees, employeeArraySize);
                break;
            case 3:
            	exit(0);
            	break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } 
	while (choice!= 3);
	
	for (int i = 0; i < employeeArraySize; ++i)
	{
        delete employees[i];
    }

    return 0;
}